SAAJID ALIYAR
JEREMY PIERCE-LORD

CONNECT 4 PROJECT

NO INSTALL INSTRUCTIONS
LOGINPAGE.HTML
the login page of the connect 4 website
MAIN.HTML
the main page of the connect 4 website
LOGINPAGESTYLE.css
the css for the login page
MAIN.css
the main pages css

the additional files are font files, and images.

This check-in we have worked on the login page, and the main game page for the connect4 assignment. The login page, has a user-login and a password, where users can log into
in order to get access into the page. Right now, the login page isn't hooked up into the database, so any password and username will work. It also has a slider which has 
the registration all in one page for easy access, and to create a simplistic login page. 
The Main page, is where the games will be displayed. The now playing game, will showcase if you would like to start a game, or play with friends, and all the options. 
When the game starts, it will fill in the grey void. When a user decides to add a new game to the side, allowing them to play multiple games to the side, they will click on the
empty screens, and this will start a new game. The game screen will switch from the mini-screen to the main one every time the player chooses to return a move.
The objects this game will have are the actual game, and friends/list and chat to become objects, where we will implement this into the site. We plan to have many more pages
and to note the dropdown bar is responsive and so far the only button that works is the logout page. We have also tried to make the page as responsive as possible by utizliing 
percentages instead of pixels. This is because when users scale down the app, they can stil see everything formatted perfectly. However we have not perfected this, and plan
to make the site fully responsive by the next check in. We plan to use javascript for the chat, all the animations, the game and even the title. 
I hope this satisfies the project check-in, and we tried to make the website as aesthetically pleasing as possible.
Thank you for reading our README!